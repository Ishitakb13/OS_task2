"""Shared helper: a thread-safe event recorder.

Every synchronization program calls rec.log(...) whenever a thread changes
state. The list of events is later turned into an HTML simulation (viz.py),
so the animation always comes from what the real threads did.
"""
import threading
import time


class Recorder:
    def __init__(self):
        self._lock = threading.Lock()      # protects the events list
        self._start = time.time()
        self.events = []

    def log(self, **fields):
        """Store one event with a timestamp (seconds since program start)."""
        with self._lock:
            fields["t"] = round(time.time() - self._start, 3)
            self.events.append(fields)
            # also print so the console shows the execution
            print(fields)
